from flask import Flask, render_template
import os

app = Flask(__name__)

@app.route('/')
def index():
    """Serve the main FutureFuel application page."""
    return render_template('index.html')

if __name__ == '__main__':
    # Bind to 0.0.0.0:5000 as required for container visibility
    app.run(host='0.0.0.0', port=5000, debug=True)
