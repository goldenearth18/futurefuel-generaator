# FutureFuel: The Hidden Genius Generator

## Overview

FutureFuel is a web application designed to generate and display interesting facts to users. The application serves as an educational tool that presents facts in an engaging, interactive format. Built with Flask as the backend framework and vanilla HTML/CSS/JavaScript for the frontend, it follows a simple server-side rendering architecture.

## System Architecture

### Frontend Architecture
- **Technology**: Vanilla HTML, CSS, and JavaScript (client-side)
- **Rendering**: Server-side rendering using Flask's Jinja2 templating engine
- **Design Pattern**: Single-page application with dynamic content updates
- **Styling**: Custom CSS with a green-themed color scheme (#e0f2e9 background, #004d40 text)
- **Responsiveness**: Mobile-first design with viewport meta tags

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Pattern**: Simple request-response model
- **Routing**: Minimal routing structure with a single main route
- **Development Mode**: Debug mode enabled for development

## Key Components

### 1. Flask Application (app.py)
- **Purpose**: Main application entry point and web server
- **Key Features**:
  - Single route handler for the index page
  - Template rendering for the main interface
  - Development server configuration
- **Architecture Decision**: Chose Flask for simplicity and rapid development, avoiding unnecessary complexity for a fact-generation application

### 2. Frontend Interface (templates/index.html)
- **Purpose**: User interface for fact display and interaction
- **Key Features**:
  - Responsive design with centered layout
  - Topic-based navigation system
  - Interactive buttons for fact generation
  - Clean, educational-focused UI design
- **Architecture Decision**: Server-side rendering chosen over client-side frameworks to minimize complexity and ensure fast initial page loads

### 3. Static Assets
- **CSS**: Inline styles for simplicity and reduced HTTP requests
- **JavaScript**: Client-side interactivity (implementation appears incomplete in current state)
- **Color Scheme**: Green theme suggesting growth, learning, and nature

## Data Flow

1. **User Request**: Browser requests the root URL
2. **Server Processing**: Flask routes the request to the index handler
3. **Template Rendering**: Jinja2 renders the HTML template
4. **Response**: Complete HTML page sent to client
5. **Client Interaction**: JavaScript handles user interactions for fact generation (pending implementation)

## External Dependencies

### Current Dependencies
- **Flask**: Web framework for Python
- **Jinja2**: Templating engine (included with Flask)

### Potential Future Dependencies
- **Fact Data Source**: Will likely require external APIs or databases for fact content
- **HTTP Client**: For fetching facts from external services
- **Database**: For storing user preferences or fact history

## Deployment Strategy

### Current Configuration
- **Host**: Configured for container deployment (0.0.0.0:5000)
- **Environment**: Development mode with debug enabled
- **Container Ready**: Port binding suitable for Docker or similar containerization

### Production Considerations
- Debug mode should be disabled
- Production WSGI server (like Gunicorn) recommended
- Environment variables for configuration management
- Static file serving optimization

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- June 27, 2025: Initial setup
- June 27, 2025: Completed FutureFuel random fact finder with emoji-based visual system, interactive topic selection, and educational facts database

## Development Notes

### Current State
- Basic Flask application structure is in place
- Frontend template exists with styling and structure
- JavaScript functionality appears incomplete (file truncated)
- No fact generation logic implemented yet

### Next Steps
- Complete JavaScript implementation for fact generation
- Implement backend endpoints for fact retrieval
- Add fact data source integration
- Implement topic-based fact filtering
- Add error handling and loading states

### Architecture Benefits
- **Simplicity**: Minimal dependencies and straightforward structure
- **Scalability**: Easy to extend with additional routes and features
- **Maintainability**: Clean separation between frontend and backend logic
- **Performance**: Server-side rendering ensures fast initial loads